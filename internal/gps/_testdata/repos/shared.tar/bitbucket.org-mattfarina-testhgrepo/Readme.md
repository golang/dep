# Test Hg Repo

This repo is used for Hg app integration testing.

See https://github.com/Masterminds/go-vcs for one such app.
