# Test Bzr Repo

This repo is used for integration testing.

For more detail see https://github.com/masterminds/go-vcs
