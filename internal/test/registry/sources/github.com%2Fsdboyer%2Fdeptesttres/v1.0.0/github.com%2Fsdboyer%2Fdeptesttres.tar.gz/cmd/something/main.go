package main

import "os"

func main() {
	os.Exit(1)
}
