package deptest

type Bar int
