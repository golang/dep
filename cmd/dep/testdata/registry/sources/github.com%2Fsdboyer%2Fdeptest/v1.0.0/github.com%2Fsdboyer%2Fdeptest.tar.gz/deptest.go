package deptest

type Foo int
