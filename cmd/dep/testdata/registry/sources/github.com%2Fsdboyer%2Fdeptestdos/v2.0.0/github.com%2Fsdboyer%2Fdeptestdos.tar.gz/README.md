## deptest

fixture to help golang/dep along
