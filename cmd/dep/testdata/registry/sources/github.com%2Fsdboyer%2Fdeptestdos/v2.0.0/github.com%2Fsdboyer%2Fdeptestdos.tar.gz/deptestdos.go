package deptestdos

import "github.com/sdboyer/deptest"

type other deptest.Foo
type Bar int
